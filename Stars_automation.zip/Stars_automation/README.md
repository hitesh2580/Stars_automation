# Stars Automation

A Python application built with PySide6 for merging and validating Excel files.

## Features

- Import two Excel files
- Merge the imported files
- Run validation checks on the merged data
- Export results to a new Excel file
- Modern user interface with progress tracking
- Detailed operation logging

## Installation

1. Create a virtual environment (recommended):
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

2. Install the required dependencies:
```bash
pip install -r requirements.txt
```

## Usage

1. Run the application:
```bash
python main.py
```

2. Use the interface to:
   - Import two Excel files using the "Import File" buttons
   - Merge the files using the "Merge Files" button
   - Run validation checks using the "Run Validation" button
   - Export the results using the "Export Results" button

3. Monitor the progress and operations in the log area at the bottom of the application.

## Requirements

- Python 3.7+
- PySide6
- pandas
- openpyxl
- xlrd
