import pandas as pd
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
                             QLabel, QFrame, QTableWidget, QTableWidgetItem,
                             QFileDialog)
from PySide6.QtCore import Qt, QThread, Signal
from loading_screen import LoadingScreen
from styles import (FILE_SECTION_STYLE, SECTION_TITLE_STYLE, BROWSE_BUTTON_STYLE,
                  PREVIEW_TABLE_STYLE)


class FileLoaderThread(QThread):
    finished = Signal(tuple)  # (file_path, dataframe)
    error = Signal(str)
    
    def __init__(self):
        super().__init__()
        self.file_path = None
    
    def run(self):
        try:
            df = pd.read_excel(self.file_path)
            self.finished.emit((self.file_path, df))
        except Exception as e:
            self.error.emit(str(e))

class ExistingFilePage(QWidget):
    home_clicked = Signal()
    file_loaded = Signal()  # Signal to indicate file is loaded
    
    def __init__(self, parent=None):
        self.show_validation_page = None  # Will be set by main window
        super().__init__(parent)
        self.current_file = None
        self.current_df = None
        self.loading_screen = LoadingScreen(self)
        self.setup_ui()
        
        # Create file loader thread
        self.file_loader = FileLoaderThread()
        self.file_loader.finished.connect(self.on_file_loaded)
        self.file_loader.error.connect(self.on_file_error)
        
    def setup_ui(self):
        # Main layout
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(40, 40, 40, 40)
        main_layout.setSpacing(20)
        
        # Content area (gray background)
        content_area = QFrame()
        content_area.setStyleSheet("""
            QFrame {
                background-color: #f5f5f5;
                border-radius: 8px;
            }
        """)
        content_layout = QVBoxLayout(content_area)
        content_layout.setContentsMargins(30, 30, 30, 30)
        content_layout.setSpacing(20)
        
        # Title
        title = QLabel("Select Compare Report")
        title.setStyleSheet("""
            QLabel {
                font-size: 16px;
                font-weight: bold;
                color: #333333;
            }
        """)
        
        # White box container
        white_box = QFrame()
        white_box.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 4px;
            }
        """)
        white_box.setMinimumHeight(400)
        
        white_box_layout = QVBoxLayout(white_box)
        white_box_layout.setContentsMargins(0, 0, 0, 0)
        white_box_layout.setSpacing(0)
        
        # Preview table
        self.preview_table = QTableWidget()
        self.preview_table.setStyleSheet(PREVIEW_TABLE_STYLE)
        self.preview_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.preview_table.verticalHeader().setVisible(False)
        self.preview_table.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.preview_table.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.preview_table.horizontalHeader().setStretchLastSection(True)
        self.preview_table.setShowGrid(True)
        
        # Button container (right-aligned)
        button_container = QFrame()
        button_layout = QHBoxLayout(button_container)
        button_layout.setContentsMargins(0, 0, 0, 0)
        button_layout.addStretch()
        
        # Browse button
        browse_btn = QPushButton("Browse File")
        browse_btn.setStyleSheet(BROWSE_BUTTON_STYLE)
        browse_btn.clicked.connect(self.load_file)
        button_layout.addWidget(browse_btn)
        

        
        # Add everything to layouts
        content_layout.addWidget(title)
        white_box_layout.addWidget(self.preview_table)
        content_layout.addWidget(white_box)
        content_layout.addWidget(button_container)
        main_layout.addWidget(content_area)
        
    def load_file(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Excel File",
            "",
            "Excel Files (*.xlsx *.xls)"
        )
        
        if file_path:
            self.loading_screen.show_loading()
            self.file_loader.file_path = file_path
            self.file_loader.start()
    
    def on_file_loaded(self, result):
        self.loading_screen.hide_loading()
        if result:
            file_path, df = result
            
            # Set up table
            self.preview_table.setRowCount(min(15, len(df)))
            self.preview_table.setColumnCount(len(df.columns))
            self.preview_table.setHorizontalHeaderLabels(df.columns)
            
            # Fill data for first 15 rows
            for row in range(min(15, len(df))):
                for col in range(len(df.columns)):
                    item = QTableWidgetItem(str(df.iloc[row, col]))
                    item.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
                    self.preview_table.setItem(row, col, item)
            
            # Adjust column widths
            for col in range(len(df.columns)):
                self.preview_table.setColumnWidth(col, 150)
            
            self.current_file = file_path
            self.current_df = df
            
            # Signal that file is loaded
            self.file_loaded.emit()
    
    def on_file_error(self, error_msg):
        self.loading_screen.hide_loading()
        from PySide6.QtWidgets import QMessageBox
        QMessageBox.critical(self, "Error", f"Error loading file: {str(error_msg)}")
    
    def clear_preview(self):
        self.preview_table.clearContents()
        self.preview_table.setRowCount(0)
        self.preview_table.setColumnCount(0)
        self.current_file = None
        self.current_df = None
        

