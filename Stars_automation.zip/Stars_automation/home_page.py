from PySide6.QtWidgets import (QWidget, QVBoxLayout, QPushButton,
                             QLabel, QFrame)
from PySide6.QtCore import Qt
from styles import HOME_BUTTON_CONTAINER_STYLE

class HomePage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()
        
    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Create container for vertical centering
        center_container = QWidget()
        center_layout = QVBoxLayout(center_container)
        center_layout.setContentsMargins(0, 0, 0, 0)
        
        # Create button container
        button_container = QFrame()
        button_container.setFixedWidth(400)
        button_container.setStyleSheet(HOME_BUTTON_CONTAINER_STYLE)
        button_layout = QVBoxLayout(button_container)
        button_layout.setSpacing(20)
        
        # Add options
        title = QLabel("Select File Mode")
        title.setStyleSheet("font-size: 20px; font-weight: bold;")
        title.setAlignment(Qt.AlignCenter)
        
        self.generate_btn = QPushButton("Generate New File")
        self.generate_btn.setFixedWidth(200)
        
        self.existing_btn = QPushButton("Use Existing File")
        self.existing_btn.setFixedWidth(200)
        
        button_layout.addWidget(title)
        button_layout.addWidget(self.generate_btn, alignment=Qt.AlignCenter)
        button_layout.addWidget(self.existing_btn, alignment=Qt.AlignCenter)
        
        # Add button container to center container
        center_layout.addStretch()
        center_layout.addWidget(button_container, alignment=Qt.AlignCenter)
        center_layout.addStretch()
        
        # Add center container to main layout
        layout.addWidget(center_container)
