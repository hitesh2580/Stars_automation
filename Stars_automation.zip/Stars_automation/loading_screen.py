from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QProgressBar
from PySide6.QtCore import Qt, QTimer

class LoadingScreen(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        
        # Set window flags
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Dialog)
        self.setAttribute(Qt.WA_TranslucentBackground)
        
        # Create layout
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignCenter)
        
        # Apply styles
        from styles import LOADING_SCREEN_STYLE
        self.setStyleSheet(LOADING_SCREEN_STYLE)
        
        # Add loading text
        self.loading_label = QLabel("Loading File...")
        layout.addWidget(self.loading_label, alignment=Qt.AlignCenter)
        
        # Add progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 0)  # Indeterminate progress
        self.progress_bar.setTextVisible(False)
        layout.addWidget(self.progress_bar, alignment=Qt.AlignCenter)
        
    def showEvent(self, event):
        super().showEvent(event)
        # Center in parent widget
        if self.parent():
            parent_rect = self.parent().rect()
            self.setGeometry(0, 0, parent_rect.width(), parent_rect.height())
    
    def show_loading(self, message="Loading File..."):
        self.loading_label.setText(message)
        self.show()
    
    def hide_loading(self):
        self.hide()
