import sys
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QPushButton, QFrame, QStackedWidget)
from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon, QPixmap

from home_page import HomePage
from new_file_page import NewFilePage
from existing_file_page import ExistingFilePage
from validation_page import ValidationPage
from styles import MAIN_STYLE, TITLE_LABEL_STYLE, TASKBAR_STYLE, NAV_BUTTON_STYLE

class StarsAutomation(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Stars Files Automation")
        self.setMinimumSize(1024, 768)
        self.resize(1024, 768)
        
        # Create main widget and layout
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        self.main_layout = QVBoxLayout(main_widget)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.main_layout.setSpacing(0)
        
        self.setStyleSheet(MAIN_STYLE)
        self.setup_ui()
        
    def setup_ui(self):
        # Create title bar
        self.setup_title_bar()
        
        # Create stacked widget for pages
        self.stacked_widget = QStackedWidget()
        
        # Create pages
        self.home_page = HomePage()
        self.new_file_page = NewFilePage()
        self.existing_file_page = ExistingFilePage()
        self.validation_page = ValidationPage()
        
        # Add pages to stacked widget
        self.stacked_widget.addWidget(self.home_page)
        self.stacked_widget.addWidget(self.new_file_page)
        self.stacked_widget.addWidget(self.existing_file_page)
        self.stacked_widget.addWidget(self.validation_page)
        
        # Create content container
        content_container = QWidget()
        content_layout = QVBoxLayout(content_container)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(0)
        content_layout.addWidget(self.stacked_widget)
        
        # Create taskbar
        self.setup_taskbar()
        
        # Add content and taskbar to main layout
        self.main_layout.addWidget(content_container)
        self.main_layout.addWidget(self.taskbar)
        self.taskbar.hide()
        
        # Connect navigation signals
        self.home_page.generate_btn.clicked.connect(self.show_new_file_page)
        self.home_page.existing_btn.clicked.connect(self.show_existing_file_page)
        self.new_file_page.home_clicked.connect(self.show_home_page)
        self.existing_file_page.home_clicked.connect(self.show_home_page)
        
        # Connect file loading signals
        self.new_file_page.files_loaded.connect(lambda: self.next_btn.setEnabled(True))
        self.existing_file_page.file_loaded.connect(lambda: self.next_btn.setEnabled(True))
        
        # Add navigation methods to pages
        self.new_file_page.show_validation_page = lambda: self.show_validation_page('new')
        self.existing_file_page.show_validation_page = lambda: self.show_validation_page('existing')
        
    def setup_title_bar(self):
        # Create title bar container
        title_container = QWidget()
        title_container.setStyleSheet("background-color: #4a90e2;")
        title_container.setFixedHeight(60)
        
        # Create title bar layout
        title_layout = QHBoxLayout(title_container)
        title_layout.setContentsMargins(20, 0, 20, 0)
        
        # Create header with logos and text
        header_container = QWidget()
        header_layout = QHBoxLayout(header_container)
        header_layout.setContentsMargins(0, 0, 0, 0)
        header_layout.setSpacing(10)
        
        # Add left star logo
        left_logo = QLabel()
        left_logo.setFixedSize(30, 30)
        left_logo.setPixmap(QIcon("resources/header_star.svg").pixmap(30, 30))
        header_layout.addWidget(left_logo)
        
        # Add title
        title_label = QLabel("STARS AUTOMATION")
        title_label.setStyleSheet(TITLE_LABEL_STYLE)
        header_layout.addWidget(title_label)
        
        # Add right star logo
        right_logo = QLabel()
        right_logo.setFixedSize(30, 30)
        right_logo.setPixmap(QIcon("resources/header_star.svg").pixmap(30, 30))
        header_layout.addWidget(right_logo)
        
        # Add header to title layout
        title_layout.addStretch()
        title_layout.addWidget(header_container)
        title_layout.addStretch()
        
        # Set window icon
        self.setWindowIcon(QIcon("resources/app_logo.svg"))
        
        self.main_layout.addWidget(title_container)
        
    def setup_taskbar(self):
        # Create taskbar container
        self.taskbar = QFrame()
        self.taskbar.setStyleSheet(TASKBAR_STYLE)
        self.taskbar.setFixedHeight(60)
        
        # Create taskbar layout
        taskbar_layout = QHBoxLayout(self.taskbar)
        taskbar_layout.setContentsMargins(20, 0, 20, 0)
        
        # Create navigation buttons
        self.back_btn = QPushButton("← Back")
        self.back_btn.setStyleSheet(NAV_BUTTON_STYLE)
        self.back_btn.clicked.connect(self.navigate_back)
        
        # Create validation buttons (initially hidden)
        self.run_validation_btn = QPushButton("Run Validation")
        self.run_validation_btn.setStyleSheet(NAV_BUTTON_STYLE)
        self.run_validation_btn.clicked.connect(self.run_validation)
        self.run_validation_btn.hide()
        
        self.save_result_btn = QPushButton("Save Result")
        self.save_result_btn.setStyleSheet(NAV_BUTTON_STYLE)
        self.save_result_btn.clicked.connect(self.save_result)
        self.save_result_btn.setEnabled(False)
        self.save_result_btn.hide()
        
        self.next_btn = QPushButton("Next →")
        self.next_btn.setStyleSheet(NAV_BUTTON_STYLE)
        self.next_btn.clicked.connect(self.navigate_next)
        
        # Add buttons to taskbar
        taskbar_layout.addWidget(self.back_btn)
        taskbar_layout.addStretch()
        taskbar_layout.addWidget(self.run_validation_btn)
        taskbar_layout.addWidget(self.save_result_btn)
        taskbar_layout.addWidget(self.next_btn)
    
    def show_new_file_page(self):
        self.new_file_page.clear_preview()
        self.stacked_widget.setCurrentWidget(self.new_file_page)
        self.taskbar.show()
        self.update_navigation()
        
    def show_existing_file_page(self):
        self.existing_file_page.clear_preview()
        self.stacked_widget.setCurrentWidget(self.existing_file_page)
        self.taskbar.show()
        self.update_navigation()
        
    def show_home_page(self):
        self.stacked_widget.setCurrentWidget(self.home_page)
        self.taskbar.hide()
        
    def show_validation_page(self, source):
        if source == 'new':
            self.validation_page.set_data_from_new_file(
                self.new_file_page.current_df,
                self.new_file_page.compare_df
            )
        else:  # existing
            self.validation_page.set_data_from_existing_file(
                self.existing_file_page.current_df
            )
        self.stacked_widget.setCurrentWidget(self.validation_page)
        self.taskbar.show()
        
        # Connect validation signals
        self.validation_page.validation_started.connect(lambda: self.run_validation_btn.setEnabled(False))
        self.validation_page.validation_completed.connect(lambda: (
            self.run_validation_btn.setEnabled(True),
            self.save_result_btn.setEnabled(True)
        ))
        
        self.update_navigation()
        
    def navigate_back(self):
        current_widget = self.stacked_widget.currentWidget()
        if current_widget == self.validation_page:
            # Go back to previous page based on data source
            if self.validation_page.is_new_file_flow:
                self.show_new_file_page()
            else:
                self.show_existing_file_page()
        else:
            # Go back to home
            self.show_home_page()
        
    def navigate_next(self):
        current_widget = self.stacked_widget.currentWidget()
        if current_widget == self.new_file_page:
            if self.new_file_page.current_df is not None and self.new_file_page.compare_df is not None:
                self.show_validation_page('new')
        elif current_widget == self.existing_file_page:
            if self.existing_file_page.current_df is not None:
                self.show_validation_page('existing')
        elif current_widget == self.validation_page:
            # Run validation when on validation page
            self.validation_page.run_validation()
        
    def update_navigation(self):
        """Update navigation buttons based on current page"""
        current_widget = self.stacked_widget.currentWidget()
        
        # Hide validation buttons by default
        self.run_validation_btn.hide()
        self.save_result_btn.hide()
        self.next_btn.show()
        
        if current_widget == self.validation_page:
            # Show validation buttons and hide next button
            self.run_validation_btn.show()
            self.save_result_btn.show()
            self.next_btn.hide()
            self.back_btn.setText("← Back")
            self.next_btn.setText("Next →")
        elif current_widget == self.new_file_page:
            self.back_btn.setText("← Home")
            self.next_btn.setText("Next →")
            self.next_btn.setEnabled(self.new_file_page.current_df is not None)
        elif current_widget == self.existing_file_page:
            self.back_btn.setText("← Home")
            self.next_btn.setText("Next →")
            self.next_btn.setEnabled(self.existing_file_page.current_df is not None)
        
    def run_validation(self):
        self.validation_page.run_validation()
    
    def save_result(self):
        self.validation_page.save_result()
        
if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    
    window = StarsAutomation()
    window.show()
    
    sys.exit(app.exec())
