import pandas as pd
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QPushButton,
                             QLabel, QFrame, QTableWidget, QTableWidgetItem,
                             QFileDialog, QHBoxLayout, QComboBox)
from PySide6.QtCore import Qt, QThread, Signal
from loading_screen import LoadingScreen


class FileLoaderThread(QThread):
    finished = Signal(tuple)  # (file_path, dataframe)
    error = Signal(str)
    
    def __init__(self):
        super().__init__()
        self.file_path = None
    
    def run(self):
        try:
            df = pd.read_excel(self.file_path)
            self.finished.emit((self.file_path, df))
        except Exception as e:
            self.error.emit(str(e))
from styles import (FILE_SECTION_STYLE, SECTION_TITLE_STYLE, BROWSE_BUTTON_STYLE,
                  VERSION_DROPDOWN_STYLE, PREVIEW_TABLE_STYLE)

class NewFilePage(QWidget):
    home_clicked = Signal()
    files_loaded = Signal()  # Signal to indicate both files are loaded
    
    def __init__(self, parent=None):
        self.show_validation_page = None  # Will be set by main window
        super().__init__(parent)
        self.current_file = None
        self.current_df = None
        self.current_version = None
        self.compare_file = None
        self.compare_df = None
        self.compare_version = None
        self.loading_screen = LoadingScreen(self)
        
        # Create file loader threads
        self.current_loader = FileLoaderThread()
        self.current_loader.finished.connect(lambda result: self.on_file_loaded(result, "current"))
        self.current_loader.error.connect(lambda error: self.on_file_error(error, "current"))
        
        self.compare_loader = FileLoaderThread()
        self.compare_loader.finished.connect(lambda result: self.on_file_loaded(result, "compare"))
        self.compare_loader.error.connect(lambda error: self.on_file_error(error, "compare"))
        
        self.setup_ui()
        
    def setup_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(40, 40, 40, 40)
        main_layout.setAlignment(Qt.AlignTop)
        main_layout.setSpacing(20)
        
        # Create both sections
        self.current_section = self.create_section("Current Run", "current")
        self.compare_section = self.create_section("Compare Run", "compare")
        
        main_layout.addWidget(self.current_section)
        main_layout.addWidget(self.compare_section)
        

        
    def create_section(self, title, section_type):
        section = QFrame()
        section.setObjectName("content-area")
        section.setStyleSheet("""
            QFrame#content-area {
                background-color: #F5F5F5;
                border-radius: 4px;
            }
        """)
        section.setMinimumWidth(800)
        
        content_layout = QVBoxLayout(section)
        content_layout.setContentsMargins(20, 20, 20, 20)
        content_layout.setSpacing(20)
        
        # Title
        title_label = QLabel(title)
        title_label.setStyleSheet("""
            QLabel {
                color: #333333;
                font-size: 16px;
                font-weight: bold;
            }
        """)
        
        # White box
        white_box = QFrame()
        white_box.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 4px;
            }
        """)
        white_box.setFixedHeight(150)
        
        white_box_layout = QVBoxLayout(white_box)
        white_box_layout.setContentsMargins(0, 0, 0, 0)
        white_box_layout.setSpacing(0)
        
        # Preview table
        preview_table = QTableWidget()
        preview_table.setStyleSheet(PREVIEW_TABLE_STYLE)
        preview_table.setEditTriggers(QTableWidget.NoEditTriggers)
        preview_table.verticalHeader().setVisible(False)
        preview_table.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        preview_table.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        preview_table.horizontalHeader().setStretchLastSection(True)
        preview_table.setShowGrid(True)
        
        if section_type == "current":
            self.current_preview = preview_table
        else:
            self.compare_preview = preview_table
        
        # Button container (right-aligned)
        button_container = QFrame()
        button_layout = QHBoxLayout(button_container)
        button_layout.setContentsMargins(0, 0, 0, 0)
        button_layout.addStretch()
        
        # Browse button
        browse_btn = QPushButton("Browse File")
        browse_btn.setStyleSheet(BROWSE_BUTTON_STYLE)
        if section_type == "current":
            browse_btn.clicked.connect(self.load_current_file)
        else:
            browse_btn.clicked.connect(self.load_compare_file)
        
        # Version dropdown
        version_combo = QComboBox()
        version_combo.addItems(["NEW", "OLD"])
        version_combo.setStyleSheet(VERSION_DROPDOWN_STYLE)
        # Set default value based on section type
        if section_type == "current":
            version_combo.setCurrentText("NEW")
            self.current_version = version_combo
        else:
            version_combo.setCurrentText("OLD")
            self.compare_version = version_combo
            
        button_layout.addWidget(browse_btn)
        button_layout.addWidget(version_combo)
        
        # Add everything to layouts
        content_layout.addWidget(title_label)
        white_box_layout.addWidget(preview_table)
        content_layout.addWidget(white_box)
        content_layout.addWidget(button_container)
        
        return section
        
    def load_current_file(self):
        self.load_file("current")
        
    def load_compare_file(self):
        self.load_file("compare")
        
    def load_file(self, section_type):
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Excel File",
            "",
            "Excel Files (*.xlsx *.xls)"
        )
        
        if file_path:
            self.loading_screen.show_loading(f"Loading {section_type.title()} File...")
            if section_type == "current":
                self.current_loader.file_path = file_path
                self.current_loader.start()
            else:
                self.compare_loader.file_path = file_path
                self.compare_loader.start()
    
    def on_file_loaded(self, result, section_type):
        self.loading_screen.hide_loading()
        if result:
            file_path, df = result
            preview_table = self.current_preview if section_type == "current" else self.compare_preview
            
            # Set up table
            preview_table.setRowCount(min(3, len(df)))
            preview_table.setColumnCount(len(df.columns))
            preview_table.setHorizontalHeaderLabels(df.columns)
            
            # Fill data for first 3 rows
            for row in range(min(3, len(df))):
                for col in range(len(df.columns)):
                    item = QTableWidgetItem(str(df.iloc[row, col]))
                    item.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
                    preview_table.setItem(row, col, item)
            
            # Adjust column widths
            for col in range(len(df.columns)):
                preview_table.setColumnWidth(col, 150)
            
            if section_type == "current":
                self.current_file = file_path
                self.current_df = df
            else:
                self.compare_file = file_path
                self.compare_df = df
            
            # Signal that files are loaded
            if self.current_df is not None and self.compare_df is not None:
                self.files_loaded.emit()
    
    def on_file_error(self, error_msg, section_type):
        self.loading_screen.hide_loading()
        from PySide6.QtWidgets import QMessageBox
        QMessageBox.critical(self, "Error", f"Error loading {section_type} file: {str(error_msg)}")
    
    def clear_preview(self):
        self.current_preview.clearContents()
        self.current_preview.setRowCount(0)
        self.current_preview.setColumnCount(0)
        self.current_file = None
        self.current_df = None
        
        self.compare_preview.clearContents()
        self.compare_preview.setRowCount(0)
        self.compare_preview.setColumnCount(0)
        self.compare_file = None
        self.compare_df = None
        

