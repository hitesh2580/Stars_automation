"""
Styles for the Stars Automation application
"""

# Common button styles
BUTTON_BASE_STYLE = """
    background-color: #4a90e2;
    color: white;
    border: none;
    border-radius: 4px;
    padding: 8px 16px;
    font-size: 14px;
    min-width: 100px;
"""

BROWSE_BUTTON_STYLE = f"""
    QPushButton {{
        {BUTTON_BASE_STYLE}
    }}
    QPushButton:hover {{
        background-color: #357abd;
    }}
"""

VERSION_DROPDOWN_STYLE = """
    QComboBox {
        background-color: white;
        color: black;
        border: 1px solid #2196F3;
        border-radius: 4px;
        padding: 7px 16px;
        font-size: 14px;
        min-width: 50px;
    }
    QComboBox:hover {
        border-color: #1E88E5;
    }
    QComboBox::drop-down {
        border: none;
        width: 20px;
    }
    QComboBox::down-arrow {
        image: url(resources/dropdown_arrow.svg);
        width: 12px;
        height: 12px;
    }
    QComboBox QAbstractItemView {
        background-color: white;
        color: black;
        selection-background-color: #E3F2FD;
        border: 1px solid #2196F3;
    }
"""

LOADING_SCREEN_STYLE = """
    LoadingScreen {
        background-color: rgba(0, 0, 0, 150);
    }
    QLabel {
        color: white;
        font-size: 16px;
        font-weight: bold;
        margin-bottom: 10px;
    }
    QProgressBar {
        border: 2px solid #2196F3;
        border-radius: 5px;
        text-align: center;
        background-color: white;
        min-width: 200px;
        max-width: 200px;
        min-height: 20px;
    }
    QProgressBar::chunk {
        background-color: #2196F3;
        border-radius: 3px;
    }
"""

PREVIEW_TABLE_STYLE = """
    QTableWidget {
        border: none;
        background-color: white;
        gridline-color: #E0E0E0;
    }
    QHeaderView::section {
        background-color: #87CEEB;
        color: black;
        font-weight: bold;
        border: 1px solid #E0E0E0;
        border-top: none;
        padding: 8px;
    }
    QTableWidget::item {
        border: 1px solid #E0E0E0;
        padding: 5px;
    }
"""

MAIN_STYLE = f"""
QMainWindow {{
    background-color: white;
}}
QPushButton {{
    {BUTTON_BASE_STYLE}
}}
QPushButton:hover {{
    background-color: #357abd;
}}
QLabel {{
    color: #2c3e50;
}}
QFrame#title-bar {{
    background-color: #4a90e2;
    border: none;
}}
QFrame#content-area {{
    background-color: white;
    border: 1px solid #e0e0e0;
    border-radius: 3px;
}}
QLineEdit {{
    padding: 8px;
    border: 1px solid #e0e0e0;
    border-radius: 3px;
    background: white;
}}
QTextEdit {{
    border: 1px solid #e0e0e0;
    border-radius: 3px;
    background: white;
}}
"""

TITLE_LABEL_STYLE = """
QLabel {
    font-size: 20px;
    font-weight: bold;
    color: white;
    margin-left: 10px;
}
"""

SECTION_TITLE_STYLE = """
QLabel {
    font-size: 18px;
    font-weight: bold;
    color: #4a90e2;
    margin-bottom: 10px;
}
"""

FILE_SECTION_STYLE = """
QFrame#content-area {
    margin: 5px;
    padding: 10px;
    max-width: 800px;
    background-color: #f5f5f5;
    border: 1px solid #ddd;
    border-radius: 4px;
}
QTableWidget {
    border: 1px solid #e0e0e0;
    background: white;
    min-height: 180px;
}
QTableWidget::item {
    padding: 6px;
}
QHeaderView::section {
    background-color: #4a90e2;
    color: white;
    font-weight: bold;
    padding: 8px;
    border: none;
}
"""

HOME_BUTTON_CONTAINER_STYLE = """
QFrame {
    background-color: white;
    border-radius: 10px;
}
"""

TASKBAR_STYLE = """
QFrame {
    background-color: white;
    border-top: 1px solid #e0e0e0;
}
"""

NAV_BUTTON_STYLE = BROWSE_BUTTON_STYLE
