import pandas as pd
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
                             QLabel, QFrame, QTableWidget, QTableWidgetItem,
                             QGridLayout, QCheckBox, QSizePolicy, QFileDialog,
                             QMessageBox)
from PySide6.QtCore import Qt, Signal, QThread
from styles import (FILE_SECTION_STYLE, SECTION_TITLE_STYLE, BROWSE_BUTTON_STYLE,
                  PREVIEW_TABLE_STYLE)
from loading_screen import LoadingScreen
from checks_code import run_selected_checks

class ValidationThread(QThread):
    finished = Signal(object)  # Will emit the result DataFrame
    error = Signal(str)
    
    def __init__(self, current_df, selected_checks, compare_df=None):
        super().__init__()
        self.current_df = current_df
        self.selected_checks = selected_checks
        self.compare_df = compare_df
    
    def run(self):
        try:
            result = run_selected_checks(
                self.current_df,
                self.selected_checks,
                self.compare_df
            )
            self.finished.emit(result)
        except Exception as e:
            self.error.emit(str(e))

class ValidationPage(QWidget):
    validation_started = Signal()  # Signal to indicate validation has started
    validation_completed = Signal()  # Signal to indicate validation is complete
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.current_df = None
        self.compare_df = None
        self.result_df = None
        self.is_new_file_flow = False
        self.loading_screen = LoadingScreen(self)
        self.validation_thread = None
        self.setup_ui()
        
    def setup_ui(self):
        # Main layout
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(40, 40, 40, 40)
        main_layout.setSpacing(20)
        
        # Content area (gray background)
        content_area = QFrame()
        content_area.setObjectName("content-area")
        content_area.setStyleSheet("""
            QFrame#content-area {
                background-color: #f5f5f5;
                border-radius: 8px;
            }
        """)
        content_area.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        content_layout = QVBoxLayout(content_area)
        content_layout.setContentsMargins(30, 30, 30, 30)
        content_layout.setSpacing(20)
        
        # Title
        title_label = QLabel("Select Validation Checks")
        title_label.setStyleSheet(SECTION_TITLE_STYLE)
        
        # White box container
        white_box = QFrame()
        white_box.setStyleSheet("""
            QFrame {
                background-color: #f5f5f5;
                border-radius: 4px;
            }
            QCheckBox {
                font-size: 16px;
                background: none;
                padding: 0;
                margin: 0;
            }
            QCheckBox::indicator {
                width: 18px;
                height: 18px;
                background-color: white;
            }
            QCheckBox::indicator:unchecked {
                border: 2px solid #2196F3;
                background-color: white;
                border-radius: 3px;
            }
            QCheckBox::indicator:checked {
                border: 2px solid #2196F3;
                background-color: #2196F3;
                border-radius: 3px;
            }
            QFrame#grid_container {
                border: 1px solid black;
                background-color: white;
            }
            QFrame#grid_container QLabel {
                border-bottom: 1px solid black;
                border-right: 1px solid black;
                background-color: white;
                padding: 12px 16px;
            }
            QFrame#grid_container QLabel[header="true"] {
                font-weight: bold;
                font-size: 18px;
                color: #2196F3;
                background-color: #f8f9fa;
                padding: 16px;
            }
            QFrame#grid_container QWidget[containerType="checkbox"] {
                border-bottom: 1px solid black;
                border-right: 1px solid black;
                background-color: white;
                padding: 0;
                margin: 0;
            }
        """)
        white_box.setMinimumHeight(400)
        white_box.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        
        white_box_layout = QVBoxLayout(white_box)
        white_box_layout.setContentsMargins(0, 0, 0, 0)
        white_box_layout.setSpacing(0)
        
        # Create a container for the grid
        grid_container = QFrame()
        grid_container.setObjectName("grid_container")
        grid_container.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        grid_layout = QGridLayout(grid_container)
        grid_layout.setSpacing(0)
        grid_layout.setContentsMargins(0, 0, 0, 0)
        
        # Add header labels
        description_header = QLabel("Description")
        description_header.setProperty("header", True)
        description_header.setMinimumHeight(50)  # Increase header height
        
        checkbox_header = QLabel("Select")
        checkbox_header.setProperty("header", True)
        checkbox_header.setAlignment(Qt.AlignCenter)
        checkbox_header.setMinimumHeight(50)  # Increase header height
        
        grid_layout.addWidget(description_header, 0, 0)
        grid_layout.addWidget(checkbox_header, 0, 1)
        
        # Add descriptions and checkboxes
        descriptions = [
            ("compare_report", "Compare Report"),
            ("measure_id_level", "Measure_ID Level Report"),
            ("measure_detail", "Measure Detail Report"),
            ("missing_measure_ids", "Missing Measure ID's Check"),
            ("missing_contracts", "Missing Contracts Check"),
            ("na_values", "NA Values Check")
        ]
        
        self.checkboxes = {}
        for i, (check_id, desc) in enumerate(descriptions, 1):
            # Description label
            label = QLabel(desc)
            label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
            grid_layout.addWidget(label, i, 0)
            
            # Create a container for the checkbox to center it
            checkbox_container = QWidget()
            checkbox_container.setProperty("containerType", "checkbox")
            checkbox_layout = QHBoxLayout(checkbox_container)
            checkbox_layout.setContentsMargins(0, 0, 0, 0)
            checkbox_layout.setSpacing(0)
            
            # Checkbox
            checkbox = QCheckBox()
            checkbox.setObjectName(check_id)
            self.checkboxes[check_id] = checkbox
            
            # Center the checkbox both horizontally and vertically
            checkbox_layout.addStretch()
            checkbox_layout.addWidget(checkbox)
            checkbox_layout.addStretch()
            
            grid_layout.addWidget(checkbox_container, i, 1)
        
        # Set column stretch to make description column wider
        grid_layout.setColumnStretch(0, 3)
        grid_layout.setColumnStretch(1, 1)
        
        white_box_layout.addWidget(grid_container)
        white_box_layout.addStretch()
        

        
        # Add everything to layouts
        content_layout.addWidget(title_label)
        content_layout.addWidget(white_box)

        main_layout.addWidget(content_area)
        
        # Initially hide the page
        self.hide()
    
    def set_data_from_new_file(self, current_df, compare_df):
        """Set data when coming from new file page"""
        self.current_df = current_df
        self.compare_df = compare_df
        self.is_new_file_flow = True
    
    def set_data_from_existing_file(self, df):
        """Set data when coming from existing file page"""
        self.current_df = df
        self.compare_df = None
        self.is_new_file_flow = False
    
    def run_validation(self):
        """Run validation checks based on the flow"""
        # Get selected validation checks
        selected_checks = [check_id for check_id, checkbox in self.checkboxes.items() 
                         if checkbox.isChecked()]
        
        if not selected_checks:
            QMessageBox.warning(self, "No Checks Selected", 
                              "Please select at least one validation check.")
            return
        
        if self.current_df is None:
            QMessageBox.warning(self, "No Data", 
                              "No data available for validation.")
            return
        
        # Show loading screen and emit signal
        self.loading_screen.show_loading()
        self.validation_started.emit()
        
        # Create and start validation thread
        self.validation_thread = ValidationThread(
            self.current_df,
            selected_checks,
            self.compare_df if self.is_new_file_flow else None
        )
        self.validation_thread.finished.connect(self.on_validation_complete)
        self.validation_thread.error.connect(self.on_validation_error)
        self.validation_thread.start()
    
    def on_validation_complete(self, result_df):
        self.loading_screen.hide_loading()
        self.result_df = result_df
        self.validation_completed.emit()
        QMessageBox.information(self, "Validation Complete", 
                              "Validation checks completed successfully!")
    
    def on_validation_error(self, error_msg):
        self.loading_screen.hide_loading()
        QMessageBox.critical(self, "Validation Error", 
                           f"Error during validation: {error_msg}")
    
    def save_result(self):
        if self.result_df is None:
            return
        
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Save Validation Results",
            "",
            "Excel Files (*.xlsx)"
        )
        
        if file_path:
            try:
                if not file_path.endswith('.xlsx'):
                    file_path += '.xlsx'
                self.result_df.to_excel(file_path, index=False)
                QMessageBox.information(self, "Success", 
                                      "Results saved successfully!")
            except Exception as e:
                QMessageBox.critical(self, "Error", 
                                   f"Error saving results: {str(e)}")
